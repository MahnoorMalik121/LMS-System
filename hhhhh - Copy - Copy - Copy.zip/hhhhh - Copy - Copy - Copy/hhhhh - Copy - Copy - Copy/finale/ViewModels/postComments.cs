﻿using finale.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace finale.ViewModels
{
    public class postComments
    {
        public post posts { get; set; }

        public comment comments { get; set; }
    }
}