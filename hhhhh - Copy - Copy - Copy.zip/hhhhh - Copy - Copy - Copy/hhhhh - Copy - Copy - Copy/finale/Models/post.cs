namespace finale.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("post")]

    public partial class post
    {
        [Key]
        public int postID { get; set; }

        public int upvote { get; set; }

        public int downvote { get; set; }

        [StringLength(50)]
        public string postTitle { get; set; }

        [StringLength(200)]
        public string description { get; set; }

        [StringLength(200)]
        public string userName { get; set; }

        [Column(TypeName = "DateTime")]
        public DateTime? postdate { get; set; }

        public ICollection<comment> Comments { get; set; }
    }
}
