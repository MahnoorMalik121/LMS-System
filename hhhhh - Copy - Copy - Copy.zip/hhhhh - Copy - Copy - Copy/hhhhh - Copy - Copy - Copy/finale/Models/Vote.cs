namespace finale.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    [Table("Vote")]

    public partial class Vote
    {
        [Key]
        public int voteid { get; set; }

        public int userid { get; set; }

  
        public int votetype { get; set; }

        public int postID { get; set; }
    }
}
