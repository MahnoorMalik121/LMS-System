namespace finale.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("comment")]
    public partial class comment
    {
      
        [Key]
        public int commentID { get; set; }
        [StringLength(50)]
        public string description { get; set; }

        [StringLength(50)]
        public string userName { get; set; }

        public int postID { get; set; }
       
        [Column(TypeName = "DateTime")]
        public DateTime? timeStamp { get; set; }

    }
}
