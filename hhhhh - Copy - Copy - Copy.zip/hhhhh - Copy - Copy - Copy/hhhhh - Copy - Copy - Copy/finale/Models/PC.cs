﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace finale.Models
{
    public class PC
    {
        public IEnumerable<post> post { get; set; }
        public IEnumerable<comment> comment { get; set; }
    }
}