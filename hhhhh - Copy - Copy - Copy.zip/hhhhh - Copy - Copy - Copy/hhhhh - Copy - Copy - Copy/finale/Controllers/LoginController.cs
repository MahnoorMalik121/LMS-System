﻿using finale.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace finale.Controllers
{
    public class LoginController : Controller
    {
        Model1 db = new Model1();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(user spcheck)
        {

            //if (ModelState.IsValid)
            //{
            using (Model1 db = new Model1())
            {
                var sp = db.users.Where(a => a.email.Equals(spcheck.email) && a.password.Equals(spcheck.password)).FirstOrDefault();

                if (sp != null)
                {
                    Session["email"] = sp.email.ToString();
                    Session["userName"] = sp.userName.ToString();
                    Session["userType"] = sp.userType.ToString();
                    Session["userID"] = sp.userID.ToString();
                    var one=sp.userType.ToString();
                    if (one == "Super")
                    {
                        return RedirectToAction("SuperView", "Login");
                    }
                    else if (one == "Student")
                    {
                        return RedirectToAction("Index2", "hello");
                    }
                    else if(one=="Instructor")
                    {
                        return RedirectToAction("Index2", "hello");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Not authorized");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "The username or Password is incorrect");
                }
                //}
            }


            return View(spcheck);
        }
        public ActionResult SuperView()
        {
            return View();
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Index", "Login");
        }
        public ActionResult SignUp()
        {

            return View();
        }
        [HttpPost]
        public ActionResult SignUp(user u)
        {

          using (var context=new Model1())
            {
                context.users.Add(u);
                context.SaveChanges();
            }
            return RedirectToAction("Index", "Login");
        }
        public ActionResult SignUpI()
        {

            return View();
        }
        [HttpPost]
        public ActionResult SignUpI(user u)
        {

            using (var context = new Model1())
            {
                context.users.Add(u);
                context.SaveChanges();
            }
            return RedirectToAction("Index", "Login");
        }
       
    }
}
