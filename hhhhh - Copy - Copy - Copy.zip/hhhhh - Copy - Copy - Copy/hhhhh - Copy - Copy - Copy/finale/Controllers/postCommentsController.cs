﻿using finale.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace finale.Controllers
{
    public class postCommentsController : Controller
    {
        // GET: postComments
        public ActionResult Index()
        {
            var pc = new postComments();
            
            return View();
        }
    }
}