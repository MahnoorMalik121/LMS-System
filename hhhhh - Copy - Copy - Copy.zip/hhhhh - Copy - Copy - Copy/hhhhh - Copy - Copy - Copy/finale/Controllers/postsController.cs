﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using finale.Models;

namespace finale.Controllers
{
    public class postsController : Controller
    {
        private Model1 db = new Model1();

        // GET: posts
        public ActionResult Index()
        {

            return View(db.posts.ToList());
            //return View(db.posts.OrderByDescending(x => x.postdate).ToList());
        }

        public ActionResult tolist()
        {
            var list1 = db.posts.ToList();
            ViewBag.model = list1;
            ViewBag.posts1 = db.posts.ToList();
            ViewBag.comment1 = db.comments.ToList();
            ViewBag.users1 = db.users.ToList();
            return View();
        }

        public ActionResult Vieww()
        {
            var posts1 = db.posts.ToList();
            ViewBag.post2 = posts1;

            var comments1 = db.posts.ToList().OrderBy(x=>x.postdate);
            ViewBag.comment2 = comments1;


            return View();
        }

        // GET: posts/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            post post = db.posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }
            return View(post);
        }
        //[HttpPost]
        //public ActionResult Details(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    post post = db.posts.Find(id);
        //    if (post == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(post);
        //}

        // GET: posts/Create
        public ActionResult Create()
        {
            return View();
        }
        public ActionResult StudentPost()
        {
            return View(db.posts.ToList());
        }

        public ActionResult Commenting()
        {
            return View(db.posts.ToList());
        }

        // POST: posts/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(post post)
        {
            post post1 = new post
            {
                postTitle = post.postTitle,
                description = post.description,
                postdate = DateTime.Now,
                upvote = 0,
            downvote = 0,
                userName= @Session["userName"].ToString()
            };
            
                db.posts.Add(post1);
                db.SaveChanges();
                return RedirectToAction("Index2", "hello");
          //  return View(post);
        }
        // GET: posts/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            post post = db.posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }
            return View(post);
        }

        // POST: posts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "postID,postTitle,description,postdate")] post post)
        {
            if (ModelState.IsValid)
            {
                db.Entry(post).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(post);
        }

        // GET: posts/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            post post = db.posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }
            return View(post);
        }
        //public ActionResult StudentPost()
        //{
        //    return View();
        //}

        // POST: posts/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            post post = db.posts.Find(id);
            db.posts.Remove(post);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
