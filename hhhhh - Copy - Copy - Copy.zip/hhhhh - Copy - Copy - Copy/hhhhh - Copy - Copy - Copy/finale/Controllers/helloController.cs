﻿using finale.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using finale.ViewModels;
using System.Net;

namespace finale.Controllers
{
    public class helloController : Controller
    {
        Model1 db = new Model1();
        // GET: hello
        public ActionResult Index()
        {
            ViewBag.post0 = getPost();
            ViewBag.comment0 = getComment();

            return View();
        }
        public List<post> getPost()
        {
            List<post> p1 = db.posts.ToList();

            return p1;
        }
        public List<comment> getComment()
        {
            List<comment> c1 = db.comments.ToList();

            return c1;
        }

     [Authorize]
        public ActionResult Index2()
        {
           
            var posts1 = db.posts.Include(x => x.Comments).ToList();
            var pos3 = from f in posts1
                       orderby f.upvote descending, f.postdate descending
                       select f;
            return View(pos3);
            //return View(db.posts.ToList());

        }

        public ActionResult IndexStudent()
        {
            var posts1 = db.posts.Include(x => x.Comments).ToList();
            return View(posts1);

        }

        [HttpPost]
        public ActionResult postReply(ReplyVM obj)
        {

            comment c = new comment();
            c.description = obj.comment;
            c.postID = obj.CID;
            //c.userName = Session["userName"].ToString();

            c.userName = Session["userName"].ToString();
            c.timeStamp = DateTime.Now;
            db.comments.Add(c);
            db.SaveChanges();

            return RedirectToAction("Index2","hello");
        }

        public ActionResult Addvote(int postid, int userid, int status)
        {
            var id = Convert.ToInt32(Session["userID"]);
            var a = db.votes.Where(s => s.postID == postid && s.userid == id).FirstOrDefault();

            if (a == null)
            {
                if (status == 1)
                {
                    post update = db.posts.Find( postid);
                    update.upvote += 1;
                    db.SaveChanges();
                }
                else if (status == 0)
                {
                    post update = db.posts.Find(postid);
                    update.downvote += 1;
                    db.SaveChanges();
                }
                db.votes.Add(new Vote() { postID = postid, userid = id, votetype = status });
                db.SaveChanges();
            }
            else if (a.votetype != status)
            {
                if (status == 0)
                {
                    post update = db.posts.ToList().Find(u => u.postID == postid);
                    update.downvote += 1;

                    // update.upvote > 0 ? update.upvote -= 1 : update.upvote = 0;
                    if (update.upvote > 0)
                    {
                        update.upvote -= 1;
                    }

                    db.SaveChanges();

                }
                else if (status == 1)
                {
                    post update = db.posts.ToList().Find(u => u.postID == postid);
                    update.upvote += 1;

                    // update.upvote > 0 ? update.upvote -= 1 : update.upvote = 0;
                    if (update.downvote > 0)
                    {
                        update.downvote -= 1;
                    }

                    db.SaveChanges();

                }
                db.votes.Remove(a);
                db.SaveChanges();
                a.votetype = status;
                db.votes.Add(a);
                db.SaveChanges();
            }

            return RedirectToAction("Index2");
        }

        // GET: posts/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            post post = db.posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }
            return View(post);
        }

        // POST: posts/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(post post)
        {
            if (ModelState.IsValid)
            {

                post.userName = (string)Session["userName"];
                post.postdate = DateTime.Now;
                db.Entry(post).State = EntityState.Modified;
                
                db.SaveChanges();
                return RedirectToAction("Index2");
            }
            return View(post);
        }


        // GET: posts/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            post post = db.posts.Find(id);
            if (post == null)
            {
                return HttpNotFound();
            }
            return View(post);
        }
        //public ActionResult StudentPost()
        //{
        //    return View();
        //}

        // POST: posts/Delete/5
        [HttpPost, ActionName("Delete")]
      
        public ActionResult DeleteConfirmed(int id)
        {

            var del = Convert.ToInt32(id);
            var del1 = from a in db.votes
                       where a.postID ==del
                       select a;

            foreach(var item in del1)
            {
                db.votes.Remove(item);
            }

            db.SaveChanges();

            var del2 = from b in db.comments
                       where b.postID == del
                       select b;
            foreach(var item in del2)
            {
                db.comments.Remove(item);
            }

            db.SaveChanges();

            post post = db.posts.Find(id);

            db.posts.Remove(post);
            db.SaveChanges();
            return RedirectToAction("Index2","hello");
        }




        // GET: comments/Edit/5
        public ActionResult Edit1(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            comment comment = db.comments.Find(id);
            if (comment == null)
            {
                return HttpNotFound();
            }
            return View(comment);
        }

        // POST: comments/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit1( comment comment)
        {
            if (ModelState.IsValid)
            {
                comment.userName = (string)Session["userName"];
                comment.timeStamp = DateTime.Now;
                
                db.Entry(comment).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index2","hello");
            }
            return View(comment);
        }

        // GET: comments/Delete/5
        public ActionResult Delete1(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            comment comment = db.comments.Find(id);
            if (comment == null)
            {
                return HttpNotFound();
            }
            return View(comment);
        }


        // POST: comments/Delete/5
        [HttpPost, ActionName("Delete1")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed1(int id)
        {

            comment comment = db.comments.Find(id);
            db.comments.Remove(comment);
            db.SaveChanges();
            return RedirectToAction("Index2", "hello");
        }
    }
}